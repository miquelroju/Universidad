#!/usr/bin/env python
# coding: utf-8

# In[1]:


import RPi.GPIO as GPIO
from time import *

print('LED on pin 17 should blink')
GPIO.setmode(GPIO.BCM)
GPIO.setup(17, GPIO.OUT)
while True:
 GPIO.output(17, True)
 sleep(0.5)
 GPIO.output(17, False)
 sleep(0.5)


# In[ ]:


import RPi.GPIO as GPIO
from time import *

print('101 en codi morse')
GPIO.setmode(GPIO.BCM)
GPIO.setup(17, GPIO.OUT)
while True:
    #numero 1
 GPIO.output(17, True)
 sleep(0.5)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(1.5)
    
    # Numero 0
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(1.5)
    
    # numero 1
    
 GPIO.output(17, True)
 sleep(0.5)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(0.5)
    
 GPIO.output(17, True)
 sleep(1)
 GPIO.output(17, False)
 sleep(1.5)


# In[ ]:





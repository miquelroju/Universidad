import RPi.GPIO as GPIO
from time import sleep
import random
from threading import Timer

foraDeTemps = False

def foraTemps():
    print ("Has perdut. Fora de temps.")
    foraDeTemps = True

pinLed = 22
pinBoto = 27

numLed = 0
numVegades = 0
numPartides = 0
numGuanyades = 0
percentatge = 0

msgInici = "Vols jugar? ('s' = si, 'n' = no) "
msgDific = "Quin nivell de- dificultat? ('f' = fàcil, 'd' = difícil) "

GPIO.setmode(GPIO.BCM)
GPIO.setup(pinBoto, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(pinLed, GPIO.OUT)

estatBoto = False

while True:
    decisio = ""
    while not decisio == "s" and not decisio == "n":
        decisio = input(msgInici)
    if decisio == "n":
        break
    numPartides = numPartides + 1
    dificultat = ""
    while not dificultat == "f" and not dificultat == "d":
        dificultat = input(msgDific)
    sleep(2)
    
    numLed = random.randint(1,6)
    i=0
    while i<numLed:
        GPIO.output(pinLed, True)
        sleep(0.5)
        GPIO.output(pinLed, False)
        i = i+1
        sleep(0.5)
    
    if dificultat == "f":
        timeout = 5
    
    if dificultat == "d":
        timeout = 2
        
    t = Timer(timeout, foraTemps)
    t.start()
    numVegades = int(input("Quantes vegades s'ha encès? "))
        
    if numVegades != None and not foraDeTemps:
        t.cancel()
        
    # No he aconseguit que quan passava el temps màxim el programa deixés d'esperar la meva resposta
        
    while True:
        estatBoto = GPIO.input(pinBoto)
        if estatBoto == False:
            break
        
    
    print("El número correcte és: ", numLed)
    if numVegades == numLed:
        print("Has guanyat!")
        numGuanyades = numGuanyades + 1
    else:
        print("Has perdut.")

percentatge = (numGuanyades / numPartides) * 100
print("Partides jugades: ", numPartides)
print("Partides guanyades: ",numGuanyades)
if numPartides>0:
    print("Percentatge de partides guanyades: ",percentatge, "%")
else:
    print("Percentatge de partides guanyades: 0.00%")
        
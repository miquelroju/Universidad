import RPi.GPIO as GPIO
from time import sleep

pinLed = 22
pinBoto = 27

GPIO.setmode(GPIO.BCM)
GPIO.setup(pinBoto, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(pinLed, GPIO.OUT)

estatBoto = False
estatAnt = True

while True:
    nouEstat = GPIO.input(pinBoto)
    if nouEstat == False and estatAnt == True:
        estatBoto = not estatBoto
        sleep(0.3)
    estatAnt = nouEstat
    GPIO.output(pinLed, estatBoto)
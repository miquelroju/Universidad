package pr2;

public class DifferentCompanyException extends RuntimeException {
	public DifferentCompanyException (String msg) {
		super(msg);
	}
	
}

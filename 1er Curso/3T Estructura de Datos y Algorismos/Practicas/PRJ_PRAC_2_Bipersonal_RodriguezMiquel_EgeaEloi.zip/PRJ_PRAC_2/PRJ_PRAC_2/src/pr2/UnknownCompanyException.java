package pr2;

public class UnknownCompanyException extends RuntimeException {
	public UnknownCompanyException (String msg) {
		super(msg);
	}

}

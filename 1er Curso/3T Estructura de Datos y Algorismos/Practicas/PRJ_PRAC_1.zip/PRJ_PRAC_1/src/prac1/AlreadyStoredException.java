package prac1;

public class AlreadyStoredException extends RuntimeException {

	public AlreadyStoredException() {}
	public AlreadyStoredException(String msg) {super(msg);}

}

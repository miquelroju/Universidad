package llistes;

public class ArrayListEDA_B {
	private int [] dades;
	private int mida;
	private int ultim;
	private static final int CAPACITAT_INICIAL = 2;
	
	public ArrayListEDA_B() {
		mida=CAPACITAT_INICIAL;  // nombre màxim d'elements disponibles 
		ultim=0; // ultim apunta al primer element buit. També ens diu quans elements hi ha 
		dades=new int[CAPACITAT_INICIAL];
	}
	
    public int size() {
        return ultim;
    }

	 public void add(int element) {

	   }

	
	public void addAll(ArrayListEDA_B elements) throws Exception {
	 }
	

	
	
 	public void  add(int index, int element) throws Exception {
 
 	}
 	
 	public void  remove (int index) throws Exception {
 
 	}
	
 	public boolean  removeObj (int elem) throws Exception {
 		return true;
 	}
 	
 	
    public Iterador iterator() {
        return new Iterador();
    }

    // classe interna té accés als atributs de la classe...
    public class Iterador {

        private int current = 0; // primer element

        public boolean hasNext() {
            return current < ultim;
        }

        public int next() throws Exception {
            if (!hasNext()) throw new Exception("no queden elements per fer next");
            return dades[current++];
        }

        public void remove() throws Exception {
            ArrayListEDA_B.this.remove(--current); // si fem this.remove pensaria que es el remove de la pròpia classe
        }
        
        public void  pinta() {
        	System.out.println("...".repeat(current)+"..🠗 ");
        	ArrayListEDA_B.this.pinta();
        }
        
    }
 
    
    
    public void  pinta() {

    	System.out.println("┌──"+"┬──".repeat(mida-1)+"┐");
    	for  (int i=0;i<ultim;i++) {
    		System.out.printf("│%2d", dades[i]);
    	}
    	for  (int i=ultim;i<mida;i++) {
    		System.out.printf("│  ", dades[i]);
    	} 
    	System.out.println("|");
    	System.out.println("└──"+"┴──".repeat(mida-1)+"┘");
    }
    
    
	 public static void main(String a[]) throws Exception{
		 
		 ArrayListEDA_B llista = new ArrayListEDA_B();
		 llista.add(1); 
		 llista.pinta();
		 llista.add(3); 
		 llista.add(5); 
		 llista.add(12); 
		 llista.pinta();
		 llista.add(1); 
		 llista.pinta();
		 llista.add(9); 
		 llista.add(23); 
		 llista.pinta();	
		 llista.add(4,34); 
		 llista.add(3,35); 
		 llista.pinta();	
		 Iterador it = llista.iterator();
		it.pinta();
		 while (it.hasNext()) {
			 try {
				 int elem=it.next();
				 System.out.println(elem);
				 it.pinta();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			 
		 }
		 
		 Teclat teclat=new Teclat();
		 int valor;
		 String opcio=teclat.Llegir_opcions("atrpf", "a:add, t:troba , r:remove,p:pinta,  f:fi");
		 while (!opcio.contentEquals("f")) {
			 switch (opcio) {
			 	case "a":
			 		valor=teclat.llegirInt(100, "valor a afegir?");
			 		llista.add(valor);
			 		break;
			 	case "r":
			 		valor=teclat.llegirInt(100,"valor a eliminar?");
				try {
					llista.removeObj(valor);
					} catch (Exception e) {
						System.out.println("error, valor no trobat");
					}
			 		break;
			 	case "p":
			 		llista.pinta();
			 		break;
			 	}
			 	opcio=teclat.Llegir_opcions("atrpf", "a:add, t:troba , r:remove,p:pinta,  f:fi");
		 }
		 System.out.println("Adeu!!");
	 }
	 
}

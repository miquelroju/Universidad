class Figura{
    constructor(puntPosicio){
        this.posicio = puntPosicio;
    }  

}
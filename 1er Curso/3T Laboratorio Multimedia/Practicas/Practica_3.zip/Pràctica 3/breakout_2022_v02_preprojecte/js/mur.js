class mur {

    constructor(nivell) {//de momento ningun parametro, cuando tengamos niveles pues el nivel para escoger array para dibujar
        this.nivell = nivell;  
        this.totxos=[];      
    }
    
    defineixNivells() { //max 5*4
        
        this.nivell = [
            {
                color: "#4CF",//blau cel
                totxos: [
                    "aaaaa",
                    "aaaaa",
                    "aaaaa",
                    "aaaaa",
                ]
            },

        ]
    }

    ferTotxo() {
        var X = 10, Y = 10;
        var posX = 136, posY = 93;
        var separacioX = 10; separacioY = 5;
         

        for (let i = 0; i == this.defineixNivells(this.nivell); i++) { //this.nivell.length=1
            for (let fil = 0; fil < this.nivell[i].this.totxos.length; fil++) {
                for (let col = 0; col < this.nivell[i].this.totxos[fil].length; col++) {

                    if (this.nivell[i].this.totxos[fil].charAt(col) == 'a') {
                        this.totxos.push([fil][col] = new Totxo(new Punt((X), (Y)), posX, posY, this.nivell[i].color));
                        console.log(this.totxos[fil][col]);
                    }
                    X += posX + separacioX;
                }
                X = 10;
                Y += posY + separacioY;
            }
        }
    }
    dibuixa(){
        for(let i=0;i<this.totxos.length;i++){
            for(let j=0;j<this.totxos[i].length;j++){
                this.totxos[i][j].draw(ctx);
                console.log()
            }
        }
    }
}
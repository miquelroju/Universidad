package Practica2Sessio3;

public class Reglamentacio extends SenyalTransit {
	
	private String significatSenyal;
	
	private int diametre;
	
	public String getSignificatSenyal() {return this.significatSenyal;}
	public int getDiametre() {return this.diametre;}

}

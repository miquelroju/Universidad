package Practica2Sessio3;

public class Indicacio extends SenyalTransit {
	
	private String significatSenyal;
	
	private int alturaRectangle;
	private int baseRectangle;
	
	public String getSignificatSenyal() {return this.significatSenyal;}
	public int getAlturaRectangle() {return this.alturaRectangle;}
	public int getBaseRectangle() {return this.baseRectangle;}

}

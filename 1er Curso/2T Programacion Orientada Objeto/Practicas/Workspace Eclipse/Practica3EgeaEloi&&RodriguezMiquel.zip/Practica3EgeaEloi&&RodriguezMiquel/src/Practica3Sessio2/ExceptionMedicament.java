package Practica3Sessio2;

public class ExceptionMedicament extends Exception {
	
	public ExceptionMedicament (String message) {
		System.out.println(message);
	}
	
}

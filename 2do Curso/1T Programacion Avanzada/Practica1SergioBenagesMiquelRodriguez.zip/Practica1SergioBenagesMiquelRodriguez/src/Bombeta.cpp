#include "Bombeta.h"

Bombeta::Bombeta()
{
    ences = false;
}

Bombeta::~Bombeta()
{
    //dtor
}


Bombeta::GetEnces()
{
    return this.ences;
}

Bombeta::SetEnces(bool param)
{
    this.ences = param;
}

Bombeta::Visualitza()
{
    if (this.ences == true) {
        cout<<"O";
    } else cout<<"-";
}

Bombeta::operator==(Bombeta b)
{
    if (this.ences == b.ences) {
        return true;
    } else return false;
}

Bombeta::operator!=(Bombeta b)
{
    return !this.operator==(b);
}



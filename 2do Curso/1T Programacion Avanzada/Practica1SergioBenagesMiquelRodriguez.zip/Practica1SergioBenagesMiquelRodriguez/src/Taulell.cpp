#include "Taulell.h"
#include <stdlib.h>

Taulell::Taulell()
{
    files = 8;
    columnes = 8;
    for(int i=0; i<files; i++) {
        for(int j=0; j<columnes; j++) {
            this.contenidor[i][j] = false;
        }
    }
}

Taulell::~Taulell()
{

}

Taulell::encendre(int quantes)
{
    for(int i=0; i<quantes; i++) {
        int m = rand() % 8 + 1;
        int n = rand() % 8 + 1;
        while(this.contenidor[m][n]==true) {
            int m = rand() % 8 + 1;
            int n = rand() % 8 + 1;
        }
        this.enceses++;
    }
}

Taulell::visualitzar()
{
    for(int i=0; i<files; i++) {
        for(int j=0; j<columnes; j++) {
            this.visualitzar();
        }
    }
}

Taulell::premerBombeta(int f, int c)
{
    // TODO
}

Taulell::apagar()
{
    for(int i=0; i<this.files; i++) {
        for(int j=0; j<this.columnes; j++) {
            this.contenidor[i][j] == false;
        }
    }
}

Taulell::GetFiles()
{
    return this.files;
}

Taulell::GetColumnes()
{
    return this.columnes;
}

Taulell::GetEnceses()
{
    return this.enceses();
}

Taulell::GetBombeta(int a, int b)
{
    return this.contenidor[a][b];
}

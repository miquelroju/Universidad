package Arbres;

public class ArbreException extends Exception {
	
	public ArbreException(String msg) {
		super(msg);
	}

}

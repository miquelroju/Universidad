package Cartes;

public class Carta {

}

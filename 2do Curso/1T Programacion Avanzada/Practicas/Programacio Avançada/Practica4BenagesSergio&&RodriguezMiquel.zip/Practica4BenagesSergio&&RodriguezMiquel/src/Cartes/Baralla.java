package Cartes;

public class Baralla {

}

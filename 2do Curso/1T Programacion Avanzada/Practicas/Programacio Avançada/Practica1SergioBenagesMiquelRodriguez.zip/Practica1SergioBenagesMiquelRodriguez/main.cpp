#include <iostream>
#include <Bombeta.h>

using namespace std;

int main()
{
    cout << "Taulell de " + GetFiles + "X" + GetColumnes << endl;
    cout << "Indica quantes bombetes vols encendre" << endl;
    cout << "Especifica un valor dins del interval [1,64]" endl;
    cin >> bombetes;
    return 0;
}

#include "Poblacio.h"

Poblacio::Poblacio()
{
    //ctor
}

Poblacio::~Poblacio()
{
    //dtor
}

#include "Vidre.h"

Vidre::Vidre()
{
    //ctor
}

Vidre::~Vidre()
{
    //dtor
}

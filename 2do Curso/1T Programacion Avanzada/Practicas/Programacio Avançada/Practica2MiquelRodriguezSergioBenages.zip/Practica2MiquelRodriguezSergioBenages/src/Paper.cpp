#include "Paper.h"

Paper::Paper()
{
    //ctor
}

Paper::~Paper()
{
    //dtor
}

#include "Rebuig.h"

Rebuig::Rebuig()
{
    //ctor
}

Rebuig::~Rebuig()
{
    //dtor
}

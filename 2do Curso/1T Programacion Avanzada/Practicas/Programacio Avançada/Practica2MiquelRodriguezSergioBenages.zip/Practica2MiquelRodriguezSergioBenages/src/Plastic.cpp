#include "Plastic.h"

Plastic::Plastic()
{
    //ctor
}

Plastic::~Plastic()
{
    //dtor
}

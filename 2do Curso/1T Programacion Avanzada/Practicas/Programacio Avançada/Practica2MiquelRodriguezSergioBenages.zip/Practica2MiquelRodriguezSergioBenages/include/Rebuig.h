#ifndef REBUIG_H
#define REBUIG_H


class Rebuig
{
    public:
        Rebuig();
        virtual ~Rebuig();

    protected:

    private:
};

#endif // REBUIG_H

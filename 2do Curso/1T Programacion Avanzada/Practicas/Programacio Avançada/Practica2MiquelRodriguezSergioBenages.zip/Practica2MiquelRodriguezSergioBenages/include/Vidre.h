#ifndef VIDRE_H
#define VIDRE_H


class Vidre
{
    public:
        Vidre();
        virtual ~Vidre();

    protected:

    private:
};

#endif // VIDRE_H

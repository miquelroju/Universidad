#include "Organic.h"

Organic::Organic()
{
    //ctor
}

Organic::~Organic()
{
    //dtor
}

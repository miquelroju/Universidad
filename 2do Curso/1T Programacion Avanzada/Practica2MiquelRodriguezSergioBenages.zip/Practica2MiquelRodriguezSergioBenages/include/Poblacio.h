#ifndef POBLACIO_H
#define POBLACIO_H


class Poblacio
{
    public:
        Poblacio();
        virtual ~Poblacio();

    protected:

    private:
};

#endif // POBLACIO_H

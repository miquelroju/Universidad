#ifndef PAPER_H
#define PAPER_H


class Paper
{
    public:
        Paper();
        virtual ~Paper();

    protected:

    private:
};

#endif // PAPER_H

#ifndef PLASTIC_H
#define PLASTIC_H


class Plastic
{
    public:
        Plastic();
        virtual ~Plastic();

    protected:

    private:
};

#endif // PLASTIC_H

#ifndef ORGANIC_H
#define ORGANIC_H


class Organic
{
    public:
        Organic();
        virtual ~Organic();

    protected:

    private:
};

#endif // ORGANIC_H
